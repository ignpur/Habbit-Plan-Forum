﻿using Microsoft.AspNetCore.Identity;

namespace HabitPlanForum.Server.Auth.Model
{
    public class ForumUser : IdentityUser
    {
    }
}
